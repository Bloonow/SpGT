#!/bin/bash
source ~/.bashrc
module purge
module load gcc/9.3 cuda/11.8 cudnn/8.6.0_cuda11.x anaconda/2020.11
source activate bpy
export PYTHONUNBUFFERED=1

date
tar -xf /data/home/scv9456/run/bln/DarcyR1024.tar -C /dev/shm
date

RUN_FILE=/data/home/scv9456/run/bln/SpGT/run/darcy_train_ddp_weak.py

torchrun --standalone --nnodes=1 --nproc-per-node=7 $RUN_FILE
